let lastScrollTop = 0;
const delta = 5;
const fixBox = document.querySelector('.bottomNav');
const fixBoxHeight = fixBox.offsetHeight;
let didScroll;

//스크롤 이벤트 
window.onscroll = function(e) {
    didScroll = true;
};

setInterval(function(){
    if(didScroll){
        hasScrolled();
        didScroll = false;
    }
}, 250);

function hasScrolled(){
const nowScrollTop = window.scrollY;
if(Math.abs(lastScrollTop - nowScrollTop) <= delta){
    return;
}
if(nowScrollTop > lastScrollTop && nowScrollTop > fixBoxHeight){
    fixBox.classList.remove('show');
}else{
    if(nowScrollTop+window.innerHeight<document.body.offsetHeight){
        fixBox.classList.add('show');
    }
}
lastScrollTop = nowScrollTop;

}
