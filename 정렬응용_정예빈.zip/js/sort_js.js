document.addEventListener("DOMContentLoaded", function () {

    const select = document.querySelector("select");
    const ul = document.querySelector("#content ul")

    select.addEventListener("change", function() {
        const ab = this.value;
        const lis = Array.from(document.querySelectorAll("ul > li"));

        const strName = ab;
        slideTarget(strName.substr(4, 1));

        function slideTarget(n) {

            let datelis;

            if (n == 0) {
                //새로고침
                location.reload(true);

            } else if (n == 1) {
                // 날짜 내림차순
                datelis = lis.sort(function (a, b) {
                    const dateA = new Date(a.querySelector("span.date").textContent);
                    const dateB = new Date(b.querySelector("span.date").textContent);
                    return dateB - dateA;
                });

            } else if (n == 2) {
                // 가격 내림차순
                datelis = lis.sort(function (a, b) {
                    const priceA = parseInt(a.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
                    const priceB = parseInt(b.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
                    return priceB - priceA;
                });

            } else if (n == 3) {
                // 가격 오름차순
                datelis = lis.sort(function (a, b) {
                    const priceA = parseInt(a.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
                    const priceB = parseInt(b.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
                    return priceA - priceB;
                });
            }

            // DOM 재정렬
            if (datelis) {
            ul.innerHTML = "";
            datelis.forEach(function (li) {
                ul.appendChild(li);
            });
            }
        }

    });
});